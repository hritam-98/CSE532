HW2 CSE532:

Student name: Hritam Basak
ID: 114783055

Task1:
For the first task, I have run the following command in db2cmd to create the tanle:
"db2 -tf C:createtable.sql"

Then the table is load using the following command in db2cmd:
"db2 -tf C:load.sql"


Task2:
I have run the following command to run PearsonCC():
"db2 -td@ -f C:PearsonCCsp.sql"

Task3:
The following command is run in cmd to run PearsonCC.java file:
"javac PearsonCC.java"
"java PEarsonCC"


Extra task:
To run the user defined function, i have run the following:
"db2 -td@ -f C:PearsonCCudf.sql"


